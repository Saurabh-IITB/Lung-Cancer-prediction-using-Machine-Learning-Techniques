Lung Cancer Prediction using Machine Learning Techniques | Krutanic, ML
•	Using symptoms and experiences as features, supervised ML models are utilized for early diagnosis of lung cancer.
•	Utilized Logistic Regression, Random Forest, Support Vector Machine, K-Nearest Neighbors (KNN) and Decision Tree giving an accuracy score of 97.44%, 97.44%, 96.15%, 92.31% and 96.31% respectively.
